'use strict';

/**
 * @ngdoc function
 * @name audiofillApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the audiofillApp
 */
angular.module('audiofillApp')
  .controller('AboutCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
